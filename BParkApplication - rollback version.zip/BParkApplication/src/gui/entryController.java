package gui;

	import javafx.fxml.FXML;
	import javafx.scene.control.Button;

	public class entryController {

	    @FXML
	    private Button costBtn;

	    @FXML
	    private Button manBtn;

	    @FXML
	    private Button staffBtn;
	    
	    
	}


